
    <!-- BEGIN: Vendor JS-->
    <script src="<?php echo base_url();?>assets/app-assets/vendors/js/vendors.min.js"></script>
    <!-- BEGIN Vendor JS-->

    <!-- BEGIN: Page Vendor JS-->
    <!-- END: Page Vendor JS-->

    <!-- BEGIN: Theme JS-->
    <script src="<?php echo base_url();?>assets/app-assets/js/core/app-menu.js"></script>
    <script src="<?php echo base_url();?>assets/app-assets/js/core/app.js"></script>
    <script src="<?php echo base_url();?>assets/app-assets/js/scripts/components.js"></script>
    <!-- END: Theme JS-->

    <!-- BEGIN: Page JS-->
    <!-- END: Page JS-->

</body>
<!-- END: Body-->

</html>