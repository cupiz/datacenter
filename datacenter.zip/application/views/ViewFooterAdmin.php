 <!-- BEGIN: Footer-->
 <footer class="footer footer-static footer-light">
    <p class="clearfix blue-grey lighten-2 mb-0"><span class="float-md-left d-block d-md-inline-block mt-25">COPYRIGHT &copy; 2022<a class="text-bold-800 grey darken-2">Universitas Jendral Soedirman</a></span>
        <button id="atas" class="btn btn-primary btn-icon scroll-top" type="button"><i class="feather icon-arrow-up"></i></button>
    </p>
</footer>

<!-- END: Footer-->


<!-- BEGIN: Vendor JS-->
<script src="<?php echo base_url();?>assets/app-assets/vendors/js/vendors.min.js"></script>
<!-- BEGIN Vendor JS-->

<!-- BEGIN: Page Vendor JS-->
<script src="<?php echo base_url();?>assets/app-assets/vendors/js/forms/select/select2.full.min.js"></script>
<script src="<?php echo base_url();?>assets/app-assets/vendors/js/forms/validation/jqBootstrapValidation.js"></script>
<script src="<?php echo base_url();?>assets/app-assets/vendors/js/tables/datatable/pdfmake.min.js"></script>
<script src="<?php echo base_url();?>assets/app-assets/vendors/js/tables/datatable/vfs_fonts.js"></script>
<script src="<?php echo base_url();?>assets/app-assets/vendors/js/tables/datatable/datatables.min.js"></script>
<script src="<?php echo base_url();?>assets/app-assets/vendors/js/tables/datatable/datatables.buttons.min.js"></script>
<script src="<?php echo base_url();?>assets/app-assets/vendors/js/tables/datatable/buttons.html5.min.js"></script>
<script src="<?php echo base_url();?>assets/app-assets/vendors/js/tables/datatable/buttons.print.min.js"></script>
<script src="<?php echo base_url();?>assets/app-assets/vendors/js/tables/datatable/buttons.bootstrap.min.js"></script>
<script src="<?php echo base_url();?>assets/app-assets/vendors/js/tables/datatable/datatables.bootstrap4.min.js"></script>
<!-- END: Page Vendor JS-->

<!-- BEGIN: Theme JS-->
<script src="<?php echo base_url();?>assets/app-assets/js/core/app-menu.js"></script>
<script src="<?php echo base_url();?>assets/app-assets/js/core/app.js"></script>
<script src="<?php echo base_url();?>assets/app-assets/js/scripts/components.js"></script>
<script src="https://kit.fontawesome.com/9be337d5d6.js" crossorigin="anonymous"></script>



<!-- END: Theme JS-->

<!-- BEGIN: Page JS-->
<script src="<?php echo base_url();?>assets/app-assets/js/scripts/datatables/datatable.js"></script>
<script src="<?php echo base_url();?>assets/app-assets/js/scripts/pages/app-user.js"></script>
<script src="<?php echo base_url();?>assets/app-assets/js/scripts/navs/navs.js"></script>
<!-- END: Page JS-->

</body>
<!-- END: Body-->

</html>