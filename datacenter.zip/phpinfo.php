<?php
phpinfo();  
?>